document.addEventListener("DOMContentLoaded", function () {
    const tabs = document.querySelectorAll(".about-tab");
    const backgroundImage = document.getElementById("background-image");
    const title = document.getElementById("title");
    const subtitle = document.getElementById("subtitle");
    const description = document.getElementById("description");

    tabs.forEach(tab => {
        tab.addEventListener("click", function (event) {
            event.preventDefault();
            const imageSrc = tab.getAttribute("data-image");
            const tabTitle = tab.getAttribute("data-title");
            const tabSubtitle = tab.getAttribute("data-subtitle");
            const tabDescription = tab.getAttribute("data-description");

            backgroundImage.style.backgroundImage = `url(${imageSrc})`;
            title.textContent = tabTitle;
            subtitle.textContent = tabSubtitle;
            description.textContent = tabDescription;
        });
    });

    // Initial tab click to display the first tab's content
    tabs[0].click();
});
